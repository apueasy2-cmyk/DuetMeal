<?php
// Configuration settings for DUET Meal API (MySQL)

return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3307,
        'dbname' => 'duetmeal',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8mb4'
    ],
    'app' => [
        'name' => 'DUET Meal API',
        'currency' => 'BDT',
        'currency_symbol' => '৳',
        'flat_meal_rate' => 90.00,
        'lunch_cutoff_time' => '12:00:00',
        'dinner_guest_advance_hours' => 24,
        'max_guests' => 10,
        'upload_dir' => __DIR__ . '/../uploads/profiles/',
        'base_url' => '/duetmealapi',
    ]
];
